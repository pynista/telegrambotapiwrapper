# -*- coding: utf-8 -*-
# Copyright (c) 2019 Dzmitry Maliuzhenets; MIT License

"""Пакет содержит типы данных и методы API телеграмма."""
