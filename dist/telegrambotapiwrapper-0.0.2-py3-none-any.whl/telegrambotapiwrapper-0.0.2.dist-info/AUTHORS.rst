telegrambotapiwrapper is written and maintained by `Dzmitry Maliuzhenets`_

.. _Dzmitry Maliuzhenets: dzmitrymaliuzhenets -at- gmail dot com
